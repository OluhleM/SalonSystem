document.addEventListener('DOMContentLoaded', function () {
  const editBtn = document.querySelector('.edit-btn');
  const inputs = document.querySelectorAll('.info input');

  editBtn.addEventListener('click', function () {
    inputs.forEach(input => {
      input.disabled = !input.disabled;
    });

    if (editBtn.textContent === 'Edit') {
      editBtn.textContent = 'Save';
      editBtn.style.backgroundColor = '#4CAF50';
    } else {
      editBtn.textContent = 'Edit';
      editBtn.style.backgroundColor = 'hotpink';
      alert('Changes saved (not stored yet)');
    }
  });
});
